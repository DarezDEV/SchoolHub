import { useEffect, useMemo, useState } from 'react';
import MainLayout from '../../layouts/MainLayout';
import { Button, Input } from '../../components/common';
import { courseService, schoolService, subjectService } from '../../services/supabase';
import type { Course, Subject, Curso, EstudianteListItem, Materia, ProfesorListItem } from '../../types';

type SectionKey = 'cursos' | 'materias' | 'estudiantes' | 'profesores';

interface CourseFormState {
  name: string;
  code: string;
  academic_year: string;
  section: string;
  description: string;
}

interface SubjectFormState {
  name: string;
  code: string;
  description: string;
}

interface EstudianteFormState {
  nombre: string;
  email: string;
  curso_id: string;
}

interface ProfesorFormState {
  nombre: string;
  email: string;
  materia_id: string;
  curso_id: string;
}

const emptyCourseForm: CourseFormState = {
  name: '',
  code: '',
  academic_year: '',
  section: '',
  description: '',
};

const emptySubjectForm: SubjectFormState = {
  name: '',
  code: '',
  description: '',
};

const emptyEstudianteForm: EstudianteFormState = {
  nombre: '',
  email: '',
  curso_id: '',
};

const emptyProfesorForm: ProfesorFormState = {
  nombre: '',
  email: '',
  materia_id: '',
  curso_id: '',
};

function formatError(error: unknown, fallback: string) {
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}

export default function CoordinatorDashboard() {
  const [activeSection, setActiveSection] = useState<SectionKey>('cursos');

  const [courses, setCourses] = useState<Course[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [cursos, setCursos] = useState<Curso[]>([]);
  const [materias, setMaterias] = useState<Materia[]>([]);
  const [estudiantes, setEstudiantes] = useState<EstudianteListItem[]>([]);
  const [profesores, setProfesores] = useState<ProfesorListItem[]>([]);

  const [courseForm, setCourseForm] = useState<CourseFormState>(emptyCourseForm);
  const [subjectForm, setSubjectForm] = useState<SubjectFormState>(emptySubjectForm);
  const [estudianteForm, setEstudianteForm] = useState<EstudianteFormState>(emptyEstudianteForm);
  const [profesorForm, setProfesorForm] = useState<ProfesorFormState>(emptyProfesorForm);

  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);
  const [editingSubjectId, setEditingSubjectId] = useState<string | null>(null);
  const [editingEstudianteId, setEditingEstudianteId] = useState<string | null>(null);
  const [editingProfesorId, setEditingProfesorId] = useState<string | null>(null);

  const [loadingCourses, setLoadingCourses] = useState(true);
  const [loadingSubjects, setLoadingSubjects] = useState(true);
  const [loadingCatalogs, setLoadingCatalogs] = useState(true);
  const [loadingEstudiantes, setLoadingEstudiantes] = useState(true);
  const [loadingProfesores, setLoadingProfesores] = useState(true);

  const [savingCourse, setSavingCourse] = useState(false);
  const [savingSubject, setSavingSubject] = useState(false);
  const [savingEstudiante, setSavingEstudiante] = useState(false);
  const [savingProfesor, setSavingProfesor] = useState(false);

  const [courseError, setCourseError] = useState<string | null>(null);
  const [subjectError, setSubjectError] = useState<string | null>(null);
  const [estudianteError, setEstudianteError] = useState<string | null>(null);
  const [profesorError, setProfesorError] = useState<string | null>(null);

  const [courseSuccess, setCourseSuccess] = useState<string | null>(null);
  const [subjectSuccess, setSubjectSuccess] = useState<string | null>(null);
  const [estudianteSuccess, setEstudianteSuccess] = useState<string | null>(null);
  const [profesorSuccess, setProfesorSuccess] = useState<string | null>(null);

  useEffect(() => {
    void loadCourses();
    void loadSubjects();
    void loadCatalogs();
    void loadEstudiantes();
    void loadProfesores();
  }, []);

  async function loadCourses() {
    setLoadingCourses(true);
    try {
      const data = await courseService.list();
      setCourses(data);
      setCourseError(null);
    } catch (error) {
      setCourseError(formatError(error, 'No se pudieron cargar los cursos.'));
    } finally {
      setLoadingCourses(false);
    }
  }

  async function loadSubjects() {
    setLoadingSubjects(true);
    try {
      const data = await subjectService.list();
      setSubjects(data);
      setSubjectError(null);
    } catch (error) {
      setSubjectError(formatError(error, 'No se pudieron cargar las materias.'));
    } finally {
      setLoadingSubjects(false);
    }
  }

  async function loadCatalogs() {
    setLoadingCatalogs(true);
    try {
      const [cursoData, materiaData] = await Promise.all([schoolService.listCursos(), schoolService.listMaterias()]);
      setCursos(cursoData);
      setMaterias(materiaData);
    } catch (error) {
      const message = formatError(error, 'No se pudieron cargar cursos y materias base.');
      setEstudianteError(message);
      setProfesorError(message);
    } finally {
      setLoadingCatalogs(false);
    }
  }

  async function loadEstudiantes() {
    setLoadingEstudiantes(true);
    try {
      const data = await schoolService.listEstudiantes();
      setEstudiantes(data);
      setEstudianteError(null);
    } catch (error) {
      setEstudianteError(formatError(error, 'No se pudieron cargar estudiantes.'));
    } finally {
      setLoadingEstudiantes(false);
    }
  }

  async function loadProfesores() {
    setLoadingProfesores(true);
    try {
      const data = await schoolService.listProfesores();
      setProfesores(data);
      setProfesorError(null);
    } catch (error) {
      setProfesorError(formatError(error, 'No se pudieron cargar profesores.'));
    } finally {
      setLoadingProfesores(false);
    }
  }

  function resetCourseForm() {
    setCourseForm(emptyCourseForm);
    setEditingCourseId(null);
  }

  function resetSubjectForm() {
    setSubjectForm(emptySubjectForm);
    setEditingSubjectId(null);
  }

  function resetEstudianteForm() {
    setEstudianteForm(emptyEstudianteForm);
    setEditingEstudianteId(null);
  }

  function resetProfesorForm() {
    setProfesorForm(emptyProfesorForm);
    setEditingProfesorId(null);
  }

  async function handleSubmitCourse(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingCourse(true);
    setCourseError(null);
    setCourseSuccess(null);

    try {
      const payload = {
        name: courseForm.name.trim(),
        code: courseForm.code.trim().toUpperCase(),
        academic_year: courseForm.academic_year.trim() || undefined,
        section: courseForm.section.trim() || undefined,
        description: courseForm.description.trim() || undefined,
      };

      if (editingCourseId) {
        await courseService.update(editingCourseId, payload);
        setCourseSuccess('Curso actualizado correctamente.');
      } else {
        await courseService.create(payload);
        setCourseSuccess('Curso creado correctamente.');
      }

      resetCourseForm();
      await loadCourses();
    } catch (error) {
      setCourseError(formatError(error, 'No se pudo guardar el curso.'));
    } finally {
      setSavingCourse(false);
    }
  }

  async function handleSubmitSubject(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingSubject(true);
    setSubjectError(null);
    setSubjectSuccess(null);

    try {
      const payload = {
        name: subjectForm.name.trim(),
        code: subjectForm.code.trim().toUpperCase(),
        description: subjectForm.description.trim() || undefined,
      };

      if (editingSubjectId) {
        await subjectService.update(editingSubjectId, payload);
        setSubjectSuccess('Materia actualizada correctamente.');
      } else {
        await subjectService.create(payload);
        setSubjectSuccess('Materia creada correctamente.');
      }

      resetSubjectForm();
      await loadSubjects();
    } catch (error) {
      setSubjectError(formatError(error, 'No se pudo guardar la materia.'));
    } finally {
      setSavingSubject(false);
    }
  }

  async function handleSubmitEstudiante(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingEstudiante(true);
    setEstudianteError(null);
    setEstudianteSuccess(null);

    try {
      const payload = {
        nombre: estudianteForm.nombre.trim(),
        email: estudianteForm.email.trim().toLowerCase(),
        curso_id: estudianteForm.curso_id,
      };

      if (!payload.curso_id) {
        throw new Error('Debe seleccionar un curso.');
      }

      if (editingEstudianteId) {
        await schoolService.updateEstudiante(editingEstudianteId, payload);
        setEstudianteSuccess('Estudiante actualizado correctamente.');
      } else {
        await schoolService.createEstudiante(payload);
        setEstudianteSuccess('Estudiante creado correctamente.');
      }

      resetEstudianteForm();
      await loadEstudiantes();
    } catch (error) {
      setEstudianteError(formatError(error, 'No se pudo guardar el estudiante.'));
    } finally {
      setSavingEstudiante(false);
    }
  }

  async function handleSubmitProfesor(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingProfesor(true);
    setProfesorError(null);
    setProfesorSuccess(null);

    try {
      const payload = {
        nombre: profesorForm.nombre.trim(),
        email: profesorForm.email.trim().toLowerCase(),
        materia_id: profesorForm.materia_id,
        curso_id: profesorForm.curso_id,
      };

      if (!payload.materia_id || !payload.curso_id) {
        throw new Error('Debe seleccionar materia y curso.');
      }

      if (editingProfesorId) {
        await schoolService.updateProfesor(editingProfesorId, payload);
        setProfesorSuccess('Profesor y asignacion actualizados correctamente.');
      } else {
        await schoolService.createProfesor(payload);
        setProfesorSuccess('Profesor creado y asignado correctamente.');
      }

      resetProfesorForm();
      await loadProfesores();
    } catch (error) {
      setProfesorError(formatError(error, 'No se pudo guardar el profesor.'));
    } finally {
      setSavingProfesor(false);
    }
  }

  async function handleDeleteCourse(course: Course) {
    if (!window.confirm(`Se eliminara el curso "${course.name}".`)) return;
    try {
      await courseService.remove(course.id);
      setCourseSuccess('Curso eliminado correctamente.');
      await loadCourses();
    } catch (error) {
      setCourseError(formatError(error, 'No se pudo eliminar el curso.'));
    }
  }

  async function handleDeleteSubject(subject: Subject) {
    if (!window.confirm(`Se eliminara la materia "${subject.name}".`)) return;
    try {
      await subjectService.remove(subject.id);
      setSubjectSuccess('Materia eliminada correctamente.');
      await loadSubjects();
    } catch (error) {
      setSubjectError(formatError(error, 'No se pudo eliminar la materia.'));
    }
  }

  async function handleDeleteEstudiante(estudianteId: string) {
    if (!window.confirm('Se eliminara este estudiante.')) return;

    try {
      await schoolService.deleteEstudiante(estudianteId);
      setEstudianteSuccess('Estudiante eliminado correctamente.');
      await loadEstudiantes();
      if (editingEstudianteId === estudianteId) resetEstudianteForm();
    } catch (error) {
      setEstudianteError(formatError(error, 'No se pudo eliminar el estudiante.'));
    }
  }

  async function handleDeleteProfesor(profesorId: string) {
    if (!window.confirm('Se eliminara este profesor y su asignacion.')) return;

    try {
      await schoolService.deleteProfesor(profesorId);
      setProfesorSuccess('Profesor eliminado correctamente.');
      await loadProfesores();
      if (editingProfesorId === profesorId) resetProfesorForm();
    } catch (error) {
      setProfesorError(formatError(error, 'No se pudo eliminar el profesor.'));
    }
  }

  function beginEditCourse(course: Course) {
    setActiveSection('cursos');
    setEditingCourseId(course.id);
    setCourseForm({
      name: course.name,
      code: course.code,
      academic_year: course.academic_year ?? '',
      section: course.section ?? '',
      description: course.description ?? '',
    });
  }

  function beginEditSubject(subject: Subject) {
    setActiveSection('materias');
    setEditingSubjectId(subject.id);
    setSubjectForm({
      name: subject.name,
      code: subject.code,
      description: subject.description ?? '',
    });
  }

  function beginEditEstudiante(estudiante: EstudianteListItem) {
    setActiveSection('estudiantes');
    setEditingEstudianteId(estudiante.id);
    setEstudianteForm({
      nombre: estudiante.nombre,
      email: estudiante.email,
      curso_id: estudiante.curso_id,
    });
  }

  async function beginEditProfesor(profesor: ProfesorListItem) {
    setActiveSection('profesores');
    const assignment = await schoolService.getProfesorAssignment(profesor.id);
    setEditingProfesorId(profesor.id);
    setProfesorForm({
      nombre: profesor.nombre,
      email: profesor.email,
      materia_id: assignment?.materia_id ?? '',
      curso_id: assignment?.curso_id ?? '',
    });
  }

  const canManage = useMemo(() => cursos.length > 0 && materias.length > 0, [cursos.length, materias.length]);

  return (
    <MainLayout>
      <div className="grid gap-6 lg:grid-cols-[250px_1fr]">
        <aside className="bg-white rounded-3xl border border-slate-200 p-4 shadow-sm h-fit lg:sticky lg:top-24">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Gestion escolar</p>
          <nav className="mt-4 space-y-2">
            <button type="button" onClick={() => setActiveSection('cursos')} className={`w-full text-left rounded-xl border px-4 py-3 ${activeSection === 'cursos' ? 'border-primary bg-blue-50 text-primary' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}><p className="text-sm font-semibold">Cursos</p></button>
            <button type="button" onClick={() => setActiveSection('materias')} className={`w-full text-left rounded-xl border px-4 py-3 ${activeSection === 'materias' ? 'border-primary bg-blue-50 text-primary' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}><p className="text-sm font-semibold">Materias</p></button>
            <button type="button" onClick={() => setActiveSection('estudiantes')} className={`w-full text-left rounded-xl border px-4 py-3 ${activeSection === 'estudiantes' ? 'border-primary bg-blue-50 text-primary' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}><p className="text-sm font-semibold">Estudiantes</p></button>
            <button type="button" onClick={() => setActiveSection('profesores')} className={`w-full text-left rounded-xl border px-4 py-3 ${activeSection === 'profesores' ? 'border-primary bg-blue-50 text-primary' : 'border-transparent bg-slate-50 hover:bg-slate-100'}`}><p className="text-sm font-semibold">Profesores</p></button>
          </nav>
        </aside>

        <section className="space-y-6">
          <div className="rounded-3xl border border-blue-200 bg-gradient-to-r from-white via-blue-50 to-cyan-50 p-8 shadow-sm">
            <h1 className="text-3xl font-bold tracking-tight text-text-primary">Administracion Academica</h1>
            <p className="text-text-secondary mt-2">CRUD de cursos, materias, estudiantes y profesores.</p>
            {loadingCatalogs && <p className="text-sm text-text-secondary mt-3">Cargando catalogos base...</p>}
            {!loadingCatalogs && !canManage && <p className="text-sm text-amber-700 mt-3">Debes tener cursos y materias base para operar estudiantes/profesores.</p>}
          </div>

          {activeSection === 'cursos' && (
            <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-xl font-semibold text-text-primary">{editingCourseId ? 'Editar curso' : 'Crear curso'}</h2>
                <form onSubmit={handleSubmitCourse} className="mt-5 space-y-4">
                  <Input label="Nombre" value={courseForm.name} onChange={(e) => setCourseForm((c) => ({ ...c, name: e.target.value }))} required />
                  <Input label="Codigo" value={courseForm.code} onChange={(e) => setCourseForm((c) => ({ ...c, code: e.target.value }))} required />
                  <Input label="Ano academico" value={courseForm.academic_year} onChange={(e) => setCourseForm((c) => ({ ...c, academic_year: e.target.value }))} />
                  <Input label="Seccion" value={courseForm.section} onChange={(e) => setCourseForm((c) => ({ ...c, section: e.target.value }))} />
                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Descripcion</label>
                    <textarea className="w-full min-h-24 px-4 py-2 border border-gray-300 rounded-xl" value={courseForm.description} onChange={(e) => setCourseForm((c) => ({ ...c, description: e.target.value }))} />
                  </div>
                  {courseError && <p className="text-sm text-error">{courseError}</p>}
                  {courseSuccess && <p className="text-sm text-success">{courseSuccess}</p>}
                  <div className="flex gap-2">
                    <Button type="submit" isLoading={savingCourse}>{editingCourseId ? 'Guardar cambios' : 'Crear curso'}</Button>
                    {editingCourseId && <Button type="button" variant="secondary" onClick={resetCourseForm}>Cancelar</Button>}
                  </div>
                </form>
              </section>
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Listado de cursos</h2><Button type="button" variant="secondary" onClick={() => void loadCourses()} isLoading={loadingCourses}>Recargar</Button></div>
                <div className="mt-5 space-y-3 max-h-[560px] overflow-auto pr-1">
                  {courses.map((course) => (
                    <article key={course.id} className="rounded-2xl border border-slate-200 p-4">
                      <h3 className="font-semibold">{course.name}</h3>
                      <p className="text-sm text-text-secondary">{course.code}</p>
                      <div className="mt-3 flex gap-2"><Button type="button" size="sm" onClick={() => beginEditCourse(course)}>Editar</Button><Button type="button" size="sm" variant="danger" onClick={() => void handleDeleteCourse(course)}>Eliminar</Button></div>
                    </article>
                  ))}
                  {!loadingCourses && courses.length === 0 && <p className="text-sm text-text-secondary">No hay cursos.</p>}
                </div>
              </section>
            </div>
          )}

          {activeSection === 'materias' && (
            <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-xl font-semibold text-text-primary">{editingSubjectId ? 'Editar materia' : 'Crear materia'}</h2>
                <form onSubmit={handleSubmitSubject} className="mt-5 space-y-4">
                  <Input label="Nombre" value={subjectForm.name} onChange={(e) => setSubjectForm((c) => ({ ...c, name: e.target.value }))} required />
                  <Input label="Codigo" value={subjectForm.code} onChange={(e) => setSubjectForm((c) => ({ ...c, code: e.target.value }))} required />
                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">Descripcion</label>
                    <textarea className="w-full min-h-24 px-4 py-2 border border-gray-300 rounded-xl" value={subjectForm.description} onChange={(e) => setSubjectForm((c) => ({ ...c, description: e.target.value }))} />
                  </div>
                  {subjectError && <p className="text-sm text-error">{subjectError}</p>}
                  {subjectSuccess && <p className="text-sm text-success">{subjectSuccess}</p>}
                  <div className="flex gap-2">
                    <Button type="submit" isLoading={savingSubject}>{editingSubjectId ? 'Guardar cambios' : 'Crear materia'}</Button>
                    {editingSubjectId && <Button type="button" variant="secondary" onClick={resetSubjectForm}>Cancelar</Button>}
                  </div>
                </form>
              </section>
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Listado de materias</h2><Button type="button" variant="secondary" onClick={() => void loadSubjects()} isLoading={loadingSubjects}>Recargar</Button></div>
                <div className="mt-5 space-y-3 max-h-[560px] overflow-auto pr-1">
                  {subjects.map((subject) => (
                    <article key={subject.id} className="rounded-2xl border border-slate-200 p-4">
                      <h3 className="font-semibold">{subject.name}</h3>
                      <p className="text-sm text-text-secondary">{subject.code}</p>
                      <div className="mt-3 flex gap-2"><Button type="button" size="sm" onClick={() => beginEditSubject(subject)}>Editar</Button><Button type="button" size="sm" variant="danger" onClick={() => void handleDeleteSubject(subject)}>Eliminar</Button></div>
                    </article>
                  ))}
                  {!loadingSubjects && subjects.length === 0 && <p className="text-sm text-text-secondary">No hay materias.</p>}
                </div>
              </section>
            </div>
          )}

          {activeSection === 'estudiantes' && (
            <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-xl font-semibold text-text-primary">{editingEstudianteId ? 'Editar estudiante' : 'Crear estudiante'}</h2>
                <form onSubmit={handleSubmitEstudiante} className="mt-5 space-y-4">
                  <Input label="Nombre" value={estudianteForm.nombre} onChange={(e) => setEstudianteForm((c) => ({ ...c, nombre: e.target.value }))} required />
                  <Input label="Email" type="email" value={estudianteForm.email} onChange={(e) => setEstudianteForm((c) => ({ ...c, email: e.target.value }))} required />
                  <div><label className="block text-sm font-medium text-text-primary mb-2">Curso</label><select value={estudianteForm.curso_id} onChange={(e) => setEstudianteForm((c) => ({ ...c, curso_id: e.target.value }))} className="w-full px-4 py-2 border border-gray-300 rounded-xl" required><option value="">Selecciona un curso</option>{cursos.map((curso) => <option key={curso.id} value={curso.id}>{curso.nombre} - {curso.nivel}</option>)}</select></div>
                  {estudianteError && <p className="text-sm text-error">{estudianteError}</p>}
                  {estudianteSuccess && <p className="text-sm text-success">{estudianteSuccess}</p>}
                  <div className="flex gap-2"><Button type="submit" isLoading={savingEstudiante}>{editingEstudianteId ? 'Guardar cambios' : 'Crear estudiante'}</Button>{editingEstudianteId && <Button type="button" variant="secondary" onClick={resetEstudianteForm}>Cancelar</Button>}</div>
                </form>
              </section>
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Listado de estudiantes</h2><Button type="button" variant="secondary" onClick={() => void loadEstudiantes()} isLoading={loadingEstudiantes}>Recargar</Button></div>
                <div className="mt-5 space-y-3 max-h-[560px] overflow-auto pr-1">
                  {estudiantes.map((estudiante) => (
                    <article key={estudiante.id} className="rounded-2xl border border-slate-200 p-4">
                      <h3 className="font-semibold">{estudiante.nombre}</h3><p className="text-sm text-text-secondary">{estudiante.email}</p><p className="text-sm text-text-secondary">Curso: {estudiante.cursos?.nombre} - {estudiante.cursos?.nivel}</p>
                      <div className="mt-3 flex gap-2"><Button type="button" size="sm" onClick={() => beginEditEstudiante(estudiante)}>Editar</Button><Button type="button" size="sm" variant="danger" onClick={() => void handleDeleteEstudiante(estudiante.id)}>Eliminar</Button></div>
                    </article>
                  ))}
                  {!loadingEstudiantes && estudiantes.length === 0 && <p className="text-sm text-text-secondary">No hay estudiantes.</p>}
                </div>
              </section>
            </div>
          )}

          {activeSection === 'profesores' && (
            <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-xl font-semibold text-text-primary">{editingProfesorId ? 'Editar profesor' : 'Crear profesor'}</h2>
                <form onSubmit={handleSubmitProfesor} className="mt-5 space-y-4">
                  <Input label="Nombre" value={profesorForm.nombre} onChange={(e) => setProfesorForm((c) => ({ ...c, nombre: e.target.value }))} required />
                  <Input label="Email" type="email" value={profesorForm.email} onChange={(e) => setProfesorForm((c) => ({ ...c, email: e.target.value }))} required />
                  <div><label className="block text-sm font-medium text-text-primary mb-2">Materia</label><select value={profesorForm.materia_id} onChange={(e) => setProfesorForm((c) => ({ ...c, materia_id: e.target.value }))} className="w-full px-4 py-2 border border-gray-300 rounded-xl" required><option value="">Selecciona una materia</option>{materias.map((materia) => <option key={materia.id} value={materia.id}>{materia.nombre}</option>)}</select></div>
                  <div><label className="block text-sm font-medium text-text-primary mb-2">Curso</label><select value={profesorForm.curso_id} onChange={(e) => setProfesorForm((c) => ({ ...c, curso_id: e.target.value }))} className="w-full px-4 py-2 border border-gray-300 rounded-xl" required><option value="">Selecciona un curso</option>{cursos.map((curso) => <option key={curso.id} value={curso.id}>{curso.nombre} - {curso.nivel}</option>)}</select></div>
                  {profesorError && <p className="text-sm text-error">{profesorError}</p>}
                  {profesorSuccess && <p className="text-sm text-success">{profesorSuccess}</p>}
                  <div className="flex gap-2"><Button type="submit" isLoading={savingProfesor}>{editingProfesorId ? 'Guardar cambios' : 'Crear profesor'}</Button>{editingProfesorId && <Button type="button" variant="secondary" onClick={resetProfesorForm}>Cancelar</Button>}</div>
                </form>
              </section>
              <section className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Listado de profesores</h2><Button type="button" variant="secondary" onClick={() => void loadProfesores()} isLoading={loadingProfesores}>Recargar</Button></div>
                <div className="mt-5 space-y-3 max-h-[560px] overflow-auto pr-1">
                  {profesores.map((profesor) => {
                    const asignacion = profesor.profesor_materia_curso?.[0];
                    return (
                      <article key={profesor.id} className="rounded-2xl border border-slate-200 p-4">
                        <h3 className="font-semibold">{profesor.nombre}</h3><p className="text-sm text-text-secondary">{profesor.email}</p>
                        <p className="text-sm text-text-secondary">Materia: {asignacion?.materias?.nombre ?? 'Sin asignar'}</p>
                        <p className="text-sm text-text-secondary">Curso: {asignacion?.cursos?.nombre ?? 'Sin asignar'} {asignacion?.cursos?.nivel ? `- ${asignacion.cursos.nivel}` : ''}</p>
                        <div className="mt-3 flex gap-2"><Button type="button" size="sm" onClick={() => void beginEditProfesor(profesor)}>Editar</Button><Button type="button" size="sm" variant="danger" onClick={() => void handleDeleteProfesor(profesor.id)}>Eliminar</Button></div>
                      </article>
                    );
                  })}
                  {!loadingProfesores && profesores.length === 0 && <p className="text-sm text-text-secondary">No hay profesores.</p>}
                </div>
              </section>
            </div>
          )}
        </section>
      </div>
    </MainLayout>
  );
}
